import { client } from '../../../lib/sanity'
import Image from 'next/image'
import { urlFor } from '../../../lib/image'
import { PortableText } from '@portabletext/react'
import Link from 'next/link'

export default async function BlogPost({ params }: { params: { slug: string } }) {
  const post = await client.fetch(
    `*[_type == "blogPost" && slug.current == $slug][0]`,
    { slug: params.slug }
  )

  if (!post) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-200 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-semibold mb-4">Post not found</h1>
          <Link href="/blog" className="text-emerald-400 hover:underline">← Back to Blog</Link>
        </div>
      </div>
    )
  }

  return (
    <main className="bg-zinc-950 text-zinc-200 min-h-screen">
      <div className="max-w-4xl mx-auto px-6 py-16">
        <Link href="/blog" className="inline-flex items-center gap-x-2 text-emerald-400 hover:text-emerald-300 mb-12">
          ← Back to all articles
        </Link>

        <div className="mb-12">
          <div className="text-emerald-400 text-sm font-mono tracking-widest mb-4">
            {new Date(post.publishedAt).toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </div>
          <h1 className="text-6xl font-semibold tracking-tighter mb-6">{post.title}</h1>
        </div>

        {post.mainImage && (
          <div className="relative w-full aspect-video mb-16 rounded-3xl overflow-hidden">
            <Image 
              src={urlFor(post.mainImage).width(1400).url()} 
              alt={post.title}
              fill
              className="object-cover"
            />
          </div>
        )}

        <div className="prose prose-invert max-w-none text-[17px] leading-relaxed">
          <PortableText value={post.body} />
        </div>

        <div className="mt-20 pt-12 border-t border-zinc-800 text-center">
          <Link href="/blog" className="inline-flex items-center gap-x-2 px-8 py-4 border border-zinc-700 hover:bg-zinc-900 rounded-3xl text-sm transition-all">
            ← Back to all insights
          </Link>
        </div>
      </div>
    </main>
  )
}